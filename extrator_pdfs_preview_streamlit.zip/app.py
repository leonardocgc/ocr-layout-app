import streamlit as st
import pdfplumber
import pandas as pd
import re
import tempfile
from pdf2image import convert_from_bytes
from PIL import Image

def extract_text(pdf_file):
    text = ""
    with pdfplumber.open(pdf_file) as pdf:
        for page in pdf.pages:
            text += page.extract_text() or ""
    return text

def extract_from_text(text, keyword, direction, only_numeric, skip_count):
    lines = text.split('\n')
    results = []

    for i, line in enumerate(lines):
        if keyword in line:
            try:
                if direction == 'lado direito':
                    data = line.split(keyword)[1].strip()
                elif direction == 'lado esquerdo':
                    data = line.split(keyword)[0].strip()
                elif direction == 'baixo':
                    data = lines[i + 1].strip()
                elif direction == 'cima' and i > 0:
                    data = lines[i - 1].strip()
                else:
                    data = ''
                
                if only_numeric:
                    matches = re.findall(r'\b\d[\d,.]*\b', data)
                    data = matches[skip_count] if len(matches) > skip_count else ''
                else:
                    words = re.findall(r'\S+', data)
                    data = words[skip_count] if len(words) > skip_count else ''
                    
                results.append(data)
            except:
                results.append('')
    return results[-1] if results else None

def process_pdf_file(file, campos):
    text = extract_text(file)
    data = {"Arquivo": file.name}
    for campo in campos:
        keyword, direction, only_numeric, skip_count = campo
        value = extract_from_text(text, keyword, direction, only_numeric, skip_count)
        data[keyword] = value
    return data

st.set_page_config(page_title="Extrator de PDFs com Visualização", layout="wide")
st.title("📄 Extrator de Dados com Pré-visualização de PDFs")

uploaded_file = st.file_uploader("1️⃣ Selecione um PDF para configurar extrações", type="pdf")

if uploaded_file:
    st.subheader("📷 Visualização Gráfica (primeiras páginas)")
    images = convert_from_bytes(uploaded_file.read(), first_page=1, last_page=2, fmt='jpeg')
    for img in images:
        st.image(img, use_column_width=True)

    uploaded_file.seek(0)
    text = extract_text(uploaded_file)
    st.subheader("📝 Texto extraído do PDF")
    st.text_area("Conteúdo completo", text, height=300)

    st.subheader("🔍 Configurar Campos para Extração")
    campos = []
    qtd_campos = st.number_input("Quantos campos deseja configurar?", min_value=1, max_value=10, value=2)

    for i in range(qtd_campos):
        st.markdown(f"### Campo {i+1}")
        col1, col2, col3 = st.columns(3)
        with col1:
            keyword = st.text_input(f"Palavra-chave {i+1}", key=f"keyword_{i}")
        with col2:
            direction = st.selectbox(f"Direção {i+1}", ['lado direito', 'lado esquerdo', 'baixo', 'cima'], key=f"dir_{i}")
        with col3:
            only_numeric = st.checkbox(f"Apenas número? {i+1}", key=f"num_{i}")
        skip_count = st.number_input(f"Ignorar quantas ocorrências? {i+1}", min_value=0, max_value=10, value=0, key=f"skip_{i}")
        
        if keyword:
            campos.append((keyword, direction, only_numeric, skip_count))
            result = extract_from_text(text, keyword, direction, only_numeric, skip_count)
            st.success(f"Valor encontrado: **{result}**")

    if campos:
        st.divider()
        st.subheader("📁 Agora selecione os PDFs para processar em lote")
        uploaded_files = st.file_uploader("Selecione múltiplos PDFs", type=["pdf"], accept_multiple_files=True)

        if uploaded_files:
            if st.button("📊 Processar PDFs e gerar Excel"):
                resultados = []
                for file in uploaded_files:
                    resultado = process_pdf_file(file, campos)
                    resultados.append(resultado)

                df = pd.DataFrame(resultados)
                with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
                    df.to_excel(tmp.name, index=False)
                    tmp_path = tmp.name

                st.success("✅ Processamento concluído!")
                st.download_button(
                    label="📥 Baixar resultado em Excel",
                    data=open(tmp_path, "rb"),
                    file_name="resultado_extracao.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
